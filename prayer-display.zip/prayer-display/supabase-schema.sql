-- ============================================================
--  לוח זמני תפילה — סכמת Supabase
--  הרץ את כל הקובץ הזה ב: Supabase → SQL Editor → New query → Run
-- ============================================================

-- ---------- טבלת הגדרות (שורה אחת) ----------
create table if not exists public.settings (
  id            int primary key default 1,
  location_name text default 'ירושלים',
  latitude      double precision default 31.7683,
  longitude     double precision default 35.2137,
  elevation     double precision default 0,
  timezone      text default 'Asia/Jerusalem',
  tzeit_angle   double precision default 8.5,
  updated_at    timestamptz default now(),
  constraint settings_single_row check (id = 1)
);
insert into public.settings (id) values (1) on conflict (id) do nothing;

-- ---------- זמני תפילה ----------
create table if not exists public.prayer_times (
  id         uuid primary key default gen_random_uuid(),
  label      text not null,
  time       text not null,          -- "HH:MM"
  note       text,
  active     boolean default true,
  sort_order int default 0,
  updated_at timestamptz default now()
);

-- ---------- פרסומים / הודעות ----------
create table if not exists public.announcements (
  id         uuid primary key default gen_random_uuid(),
  title      text,
  body       text,
  image_url  text,
  active     boolean default true,
  sort_order int default 0,
  created_at timestamptz default now()
);

-- ---------- נתוני התחלה לדוגמה ----------
insert into public.prayer_times (label, time, sort_order) values
  ('שחרית', '06:30', 10),
  ('מנחה',  '13:15', 20),
  ('ערבית', '19:45', 30)
on conflict do nothing;

-- ============================================================
--  RLS — הרשאות
--  הערת אבטחה: המדיניות למטה מאפשרת קריאה וכתיבה עם ה-anon key,
--  כי הפאנל עובד ללא התחברות (מוגן בקוד PIN בצד הלקוח בלבד).
--  זה מתאים לכלי פנימי שכתובת ה-/admin שלו פרטית.
--  לאבטחה אמיתית — הפעל Supabase Auth והחלף את מדיניות הכתיבה
--  ל: using (auth.role() = 'authenticated').
-- ============================================================
alter table public.settings      enable row level security;
alter table public.prayer_times  enable row level security;
alter table public.announcements enable row level security;

do $$
declare t text;
begin
  foreach t in array array['settings','prayer_times','announcements'] loop
    execute format('drop policy if exists "read %1$s"  on public.%1$s;', t);
    execute format('drop policy if exists "write %1$s" on public.%1$s;', t);
    execute format('create policy "read %1$s"  on public.%1$s for select using (true);', t);
    execute format('create policy "write %1$s" on public.%1$s for all using (true) with check (true);', t);
  end loop;
end $$;

-- ============================================================
--  Realtime — עדכון מיידי של המסך בכל שינוי
-- ============================================================
do $$
begin
  begin execute 'alter publication supabase_realtime add table public.settings';      exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.prayer_times';   exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.announcements';  exception when duplicate_object then null; end;
end $$;

-- ============================================================
--  Storage — דלי לתמונות הפרסומים
-- ============================================================
insert into storage.buckets (id, name, public)
values ('announcements', 'announcements', true)
on conflict (id) do nothing;

drop policy if exists "read announcement images"   on storage.objects;
drop policy if exists "upload announcement images"  on storage.objects;
drop policy if exists "delete announcement images"  on storage.objects;

create policy "read announcement images"
  on storage.objects for select
  using (bucket_id = 'announcements');

create policy "upload announcement images"
  on storage.objects for insert
  with check (bucket_id = 'announcements');

create policy "delete announcement images"
  on storage.objects for delete
  using (bucket_id = 'announcements');
