import { useEffect, useState } from 'react';

const ROTATE_MS = 12000;

export default function Announcements({ items }) {
  const [idx, setIdx] = useState(0);

  const active = (items || []).filter((a) => a.active);

  useEffect(() => {
    if (active.length <= 1) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % active.length), ROTATE_MS);
    return () => clearInterval(t);
  }, [active.length]);

  useEffect(() => {
    if (idx >= active.length) setIdx(0);
  }, [active.length, idx]);

  if (active.length === 0) {
    return (
      <div className="display__announce">
        <div className="announce__empty">ב"ה</div>
      </div>
    );
  }

  const a = active[idx % active.length];

  return (
    <div className="display__announce" style={{ position: 'relative' }}>
      {a.image_url && <img className="announce__img" src={a.image_url} alt="" key={a.id + '-img'} />}
      <div className="announce__text fade-enter" key={a.id + '-txt'}>
        {a.title && <div className="announce__title">{a.title}</div>}
        {a.body && <div className="announce__body">{a.body}</div>}
      </div>
      {active.length > 1 && (
        <div className="announce__dots">
          {active.map((_, i) => (
            <span key={i} className={'dot' + (i === idx % active.length ? ' dot--on' : '')} />
          ))}
        </div>
      )}
    </div>
  );
}
