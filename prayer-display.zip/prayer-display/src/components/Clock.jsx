import { useEffect, useState } from 'react';

export default function Clock({ timezone = 'Asia/Jerusalem' }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const parts = new Intl.DateTimeFormat('he-IL', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: timezone,
  }).formatToParts(now);

  const get = (t) => parts.find((p) => p.type === t)?.value || '00';
  const hh = get('hour');
  const mm = get('minute');
  const ss = get('second');

  return (
    <div className="clock" aria-label="שעון">
      {hh}:{mm}
      <span className="clock__seconds">:{ss}</span>
    </div>
  );
}
