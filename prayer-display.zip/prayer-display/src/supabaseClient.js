import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// The app runs even without Supabase configured (shows default content),
// so previewing before setup doesn't crash.
export const isSupabaseConfigured = Boolean(url && anonKey);

export const supabase = isSupabaseConfigured
  ? createClient(url, anonKey, { realtime: { params: { eventsPerSecond: 2 } } })
  : null;

export const ADMIN_PIN = import.meta.env.VITE_ADMIN_PIN || '';
