import { useEffect, useMemo, useState } from 'react';
import { supabase, isSupabaseConfigured } from '../supabaseClient.js';
import { computeZmanim } from '../lib/zmanim.js';
import { hebrewDateString, weekdayString, parashaString, holidaysString } from '../lib/hebrewDate.js';
import Clock from '../components/Clock.jsx';
import Announcements from '../components/Announcements.jsx';

const DEFAULT_SETTINGS = {
  id: 1,
  location_name: 'ירושלים',
  latitude: 31.7683,
  longitude: 35.2137,
  elevation: 0,
  timezone: 'Asia/Jerusalem',
  tzeit_angle: 8.5,
};

const DEFAULT_PRAYERS = [
  { id: 'd1', label: 'שחרית', time: '06:30', note: '', active: true, sort_order: 1 },
  { id: 'd2', label: 'מנחה', time: '13:15', note: '', active: true, sort_order: 2 },
  { id: 'd3', label: 'ערבית', time: '19:45', note: '', active: true, sort_order: 3 },
];

function minutesNow(timezone) {
  const p = new Intl.DateTimeFormat('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: timezone,
  }).formatToParts(new Date());
  const h = +(p.find((x) => x.type === 'hour')?.value || 0);
  const m = +(p.find((x) => x.type === 'minute')?.value || 0);
  return h * 60 + m;
}

function toMinutes(hhmm) {
  const [h, m] = (hhmm || '').split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

export default function Display() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [prayers, setPrayers] = useState(DEFAULT_PRAYERS);
  const [announcements, setAnnouncements] = useState([]);
  const [tick, setTick] = useState(0); // forces zmanim/date recompute each minute

  // Recompute halachic times + Hebrew date every minute.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 60 * 1000);
    return () => clearInterval(t);
  }, []);

  async function loadAll() {
    if (!isSupabaseConfigured) return;
    const [s, p, a] = await Promise.all([
      supabase.from('settings').select('*').eq('id', 1).maybeSingle(),
      supabase.from('prayer_times').select('*').order('sort_order', { ascending: true }),
      supabase.from('announcements').select('*').order('sort_order', { ascending: true }),
    ]);
    if (s.data) setSettings({ ...DEFAULT_SETTINGS, ...s.data });
    if (p.data && p.data.length) setPrayers(p.data);
    if (a.data) setAnnouncements(a.data);
  }

  useEffect(() => {
    loadAll();
    if (!isSupabaseConfigured) return;
    // Live updates: any change from the phone appears on the screen immediately.
    const ch = supabase
      .channel('display-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'settings' }, loadAll)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'prayer_times' }, loadAll)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements' }, loadAll)
      .subscribe();
    // Full refresh every 10 min as a safety net.
    const t = setInterval(loadAll, 10 * 60 * 1000);
    return () => {
      supabase.removeChannel(ch);
      clearInterval(t);
    };
  }, []);

  const tz = settings.timezone || 'Asia/Jerusalem';

  const zmanim = useMemo(
    () =>
      computeZmanim({
        latitude: settings.latitude,
        longitude: settings.longitude,
        elevation: settings.elevation,
        timezone: tz,
        tzeitAngle: settings.tzeit_angle,
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [settings, tick]
  );

  const dateInfo = useMemo(
    () => ({
      hebdate: hebrewDateString(),
      weekday: weekdayString(),
      parasha: parashaString(),
      holidays: holidaysString(),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tick]
  );

  // Which prayer is next (earliest active time still ahead today).
  const activePrayers = prayers.filter((p) => p.active);
  const nowMin = minutesNow(tz);
  let nextId = null;
  let best = Infinity;
  for (const p of activePrayers) {
    const m = toMinutes(p.time);
    if (m != null && m >= nowMin && m < best) {
      best = m;
      nextId = p.id;
    }
  }

  const metaParts = [dateInfo.parasha, dateInfo.holidays].filter(Boolean);

  return (
    <div className="display">
      <header className="display__header">
        <div className="header__dates">
          <div className="header__weekday">
            {dateInfo.weekday}
            {settings.location_name ? ' · ' + settings.location_name : ''}
          </div>
          <div className="header__hebdate">{dateInfo.hebdate}</div>
          {metaParts.length > 0 && (
            <div className="header__meta">
              {metaParts.map((m, i) => (
                <span key={i}>
                  {i > 0 && <span className="sep">·</span>}
                  {m}
                </span>
              ))}
            </div>
          )}
        </div>
        <Clock timezone={tz} />
      </header>

      <div className="display__panels">
        <section className="panel">
          <h2 className="panel__title">זמני התפילה</h2>
          <div className="rows">
            {activePrayers.length === 0 && (
              <div className="row">
                <span className="row__label">— טרם הוגדרו זמנים —</span>
              </div>
            )}
            {activePrayers.map((p) => (
              <div key={p.id} className={'row' + (p.id === nextId ? ' row--next' : '')}>
                <span className="row__label">
                  {p.label}
                  {p.note ? <span className="row__note">{p.note}</span> : null}
                </span>
                <span className="row__time">{p.time}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="panel">
          <h2 className="panel__title">זמנים הלכתיים</h2>
          <div className="rows">
            {zmanim.map((z) => (
              <div key={z.key} className="row">
                <span className="row__label">{z.label}</span>
                <span className="row__time">{z.time}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <Announcements items={announcements} />

      {!isSupabaseConfigured && (
        <div className="display__footer-note">
          preview mode — connect Supabase to enable remote control
        </div>
      )}
    </div>
  );
}
