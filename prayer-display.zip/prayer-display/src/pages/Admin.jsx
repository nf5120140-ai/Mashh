import { useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured, ADMIN_PIN } from '../supabaseClient.js';
import { ISRAEL_PRESETS } from '../lib/zmanim.js';

const TIMEZONES = ['Asia/Jerusalem'];

function useToast() {
  const [msg, setMsg] = useState('');
  const show = (m) => {
    setMsg(m);
    setTimeout(() => setMsg(''), 2200);
  };
  const node = msg ? <div className="toast">{msg}</div> : null;
  return [show, node];
}

/* ---------- PIN gate ---------- */
function PinGate({ onUnlock }) {
  const [val, setVal] = useState('');
  const [err, setErr] = useState(false);
  const submit = () => {
    if (val === ADMIN_PIN) {
      sessionStorage.setItem('admin_ok', '1');
      onUnlock();
    } else {
      setErr(true);
    }
  };
  return (
    <div className="pin-screen">
      <h1>ניהול הלוח</h1>
      <p className="muted">הזן קוד גישה</p>
      <input
        type="password"
        inputMode="numeric"
        value={val}
        onChange={(e) => {
          setVal(e.target.value);
          setErr(false);
        }}
        onKeyDown={(e) => e.key === 'Enter' && submit()}
        placeholder="••••"
      />
      {err && <div className="muted" style={{ color: 'var(--danger)' }}>קוד שגוי</div>}
      <button className="btn" onClick={submit}>
        כניסה
      </button>
    </div>
  );
}

/* ---------- Settings tab ---------- */
function SettingsTab({ toast }) {
  const [form, setForm] = useState({
    location_name: 'ירושלים',
    latitude: 31.7683,
    longitude: 35.2137,
    elevation: 0,
    timezone: 'Asia/Jerusalem',
    tzeit_angle: 8.5,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase
      .from('settings')
      .select('*')
      .eq('id', 1)
      .maybeSingle()
      .then(({ data }) => data && setForm((f) => ({ ...f, ...data })));
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const usePreset = (p) => setForm((f) => ({ ...f, location_name: p.name, latitude: p.latitude, longitude: p.longitude }));

  const useCurrentLocation = () => {
    if (!navigator.geolocation) return toast('אין תמיכה במיקום במכשיר');
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        setForm((f) => ({
          ...f,
          latitude: +pos.coords.latitude.toFixed(4),
          longitude: +pos.coords.longitude.toFixed(4),
        })),
      () => toast('לא ניתן לקבל מיקום')
    );
  };

  const save = async () => {
    if (!isSupabaseConfigured) return toast('יש להגדיר Supabase');
    setSaving(true);
    const payload = {
      id: 1,
      location_name: form.location_name,
      latitude: Number(form.latitude),
      longitude: Number(form.longitude),
      elevation: Number(form.elevation) || 0,
      timezone: form.timezone,
      tzeit_angle: Number(form.tzeit_angle) || 8.5,
      updated_at: new Date().toISOString(),
    };
    const { error } = await supabase.from('settings').upsert(payload, { onConflict: 'id' });
    setSaving(false);
    toast(error ? 'שגיאה בשמירה' : 'ההגדרות נשמרו');
  };

  return (
    <div className="card">
      <div className="section-title">מיקום לחישוב הזמנים</div>
      <div className="field">
        <label>שם המקום (מוצג על הלוח)</label>
        <input value={form.location_name} onChange={(e) => set('location_name', e.target.value)} />
      </div>
      <div className="chip-row">
        {ISRAEL_PRESETS.map((p) => (
          <button className="chip" key={p.name} onClick={() => usePreset(p)}>
            {p.name}
          </button>
        ))}
      </div>
      <div className="grid-2" style={{ marginTop: '0.9rem' }}>
        <div className="field">
          <label>קו רוחב</label>
          <input type="number" step="0.0001" value={form.latitude} onChange={(e) => set('latitude', e.target.value)} />
        </div>
        <div className="field">
          <label>קו אורך</label>
          <input type="number" step="0.0001" value={form.longitude} onChange={(e) => set('longitude', e.target.value)} />
        </div>
      </div>
      <button className="btn btn--ghost btn--block" onClick={useCurrentLocation}>
        השתמש במיקום הנוכחי שלי
      </button>

      <div className="grid-2" style={{ marginTop: '0.9rem' }}>
        <div className="field">
          <label>גובה (מטר, לא חובה)</label>
          <input type="number" value={form.elevation} onChange={(e) => set('elevation', e.target.value)} />
        </div>
        <div className="field">
          <label>זווית צאת הכוכבים (מעלות)</label>
          <input type="number" step="0.1" value={form.tzeit_angle} onChange={(e) => set('tzeit_angle', e.target.value)} />
        </div>
      </div>
      <p className="muted">ברירת מחדל 8.5° (ג׳ כוכבים קטנים). לצאת ר״ת אפשר להשתמש בזווית גבוהה יותר.</p>

      <button className="btn btn--block" onClick={save} disabled={saving} style={{ marginTop: '0.8rem' }}>
        {saving ? 'שומר…' : 'שמור הגדרות'}
      </button>
    </div>
  );
}

/* ---------- Prayer times tab ---------- */
const EMPTY_PRAYER = { id: null, label: '', time: '06:30', note: '', active: true, sort_order: 10 };

function PrayersTab({ toast }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY_PRAYER);

  const load = async () => {
    if (!isSupabaseConfigured) return;
    const { data } = await supabase.from('prayer_times').select('*').order('sort_order', { ascending: true });
    setItems(data || []);
  };
  useEffect(() => {
    load();
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const edit = (it) => {
    setForm(it);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const reset = () => setForm({ ...EMPTY_PRAYER, sort_order: (items.length + 1) * 10 });

  const save = async () => {
    if (!isSupabaseConfigured) return toast('יש להגדיר Supabase');
    if (!form.label.trim()) return toast('נא להזין שם תפילה');
    const payload = {
      label: form.label.trim(),
      time: form.time,
      note: form.note?.trim() || null,
      active: !!form.active,
      sort_order: Number(form.sort_order) || 0,
    };
    let error;
    if (form.id) ({ error } = await supabase.from('prayer_times').update(payload).eq('id', form.id));
    else ({ error } = await supabase.from('prayer_times').insert(payload));
    if (error) return toast('שגיאה בשמירה');
    toast(form.id ? 'עודכן' : 'נוסף');
    reset();
    load();
  };

  const remove = async (id) => {
    if (!confirm('למחוק זמן תפילה זה?')) return;
    await supabase.from('prayer_times').delete().eq('id', id);
    if (form.id === id) reset();
    load();
  };

  const toggle = async (it) => {
    await supabase.from('prayer_times').update({ active: !it.active }).eq('id', it.id);
    load();
  };

  return (
    <>
      <div className="card">
        <div className="section-title">{form.id ? 'עריכת זמן תפילה' : 'הוספת זמן תפילה'}</div>
        <div className="grid-2">
          <div className="field">
            <label>שם התפילה</label>
            <input value={form.label} onChange={(e) => set('label', e.target.value)} placeholder="שחרית / מנחה / ערבית" />
          </div>
          <div className="field">
            <label>שעה</label>
            <input type="time" value={form.time} onChange={(e) => set('time', e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>הערה (לא חובה)</label>
          <input value={form.note || ''} onChange={(e) => set('note', e.target.value)} placeholder='מניין ב׳ / "כותיקין"' />
        </div>
        <div className="grid-2">
          <div className="field">
            <label>סדר תצוגה</label>
            <input type="number" value={form.sort_order} onChange={(e) => set('sort_order', e.target.value)} />
          </div>
          <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}>
            <label className="switch">
              <input type="checkbox" checked={!!form.active} onChange={(e) => set('active', e.target.checked)} />
              מוצג על הלוח
            </label>
          </div>
        </div>
        <div className="btn-row">
          <button className="btn" onClick={save}>
            {form.id ? 'עדכן' : 'הוסף'}
          </button>
          {form.id && (
            <button className="btn btn--ghost" onClick={reset}>
              ביטול
            </button>
          )}
        </div>
      </div>

      <div className="section-title">הזמנים הקיימים</div>
      {items.length === 0 && <p className="muted">עדיין אין זמני תפילה. הוסף למעלה.</p>}
      {items.map((it) => (
        <div className={'list-item' + (it.active ? '' : ' is-off')} key={it.id}>
          <div className="list-item__main">
            <div className="list-item__label">
              {it.label} {it.note ? <span className="muted">— {it.note}</span> : ''}
            </div>
            <div className="list-item__sub">{it.time}</div>
          </div>
          <label className="switch">
            <input type="checkbox" checked={it.active} onChange={() => toggle(it)} />
          </label>
          <button className="btn btn--ghost" onClick={() => edit(it)}>
            ערוך
          </button>
          <button className="btn btn--danger" onClick={() => remove(it.id)}>
            מחק
          </button>
        </div>
      ))}
    </>
  );
}

/* ---------- Announcements tab ---------- */
const EMPTY_ANN = { id: null, title: '', body: '', image_url: '', active: true, sort_order: 10 };

function AnnouncementsTab({ toast }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY_ANN);
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    if (!isSupabaseConfigured) return;
    const { data } = await supabase.from('announcements').select('*').order('sort_order', { ascending: true });
    setItems(data || []);
  };
  useEffect(() => {
    load();
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const edit = (it) => {
    setForm(it);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const reset = () => setForm({ ...EMPTY_ANN, sort_order: (items.length + 1) * 10 });

  const uploadImage = async (file) => {
    if (!file) return;
    if (!isSupabaseConfigured) return toast('יש להגדיר Supabase');
    setUploading(true);
    const ext = file.name.split('.').pop();
    const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error } = await supabase.storage.from('announcements').upload(path, file, { upsert: true });
    if (error) {
      setUploading(false);
      return toast('שגיאה בהעלאת תמונה');
    }
    const { data } = supabase.storage.from('announcements').getPublicUrl(path);
    set('image_url', data.publicUrl);
    setUploading(false);
    toast('התמונה הועלתה');
  };

  const save = async () => {
    if (!isSupabaseConfigured) return toast('יש להגדיר Supabase');
    if (!form.title.trim() && !form.body.trim() && !form.image_url) return toast('נא להזין תוכן');
    const payload = {
      title: form.title?.trim() || null,
      body: form.body?.trim() || null,
      image_url: form.image_url || null,
      active: !!form.active,
      sort_order: Number(form.sort_order) || 0,
    };
    let error;
    if (form.id) ({ error } = await supabase.from('announcements').update(payload).eq('id', form.id));
    else ({ error } = await supabase.from('announcements').insert(payload));
    if (error) return toast('שגיאה בשמירה');
    toast(form.id ? 'עודכן' : 'נוסף');
    reset();
    load();
  };

  const remove = async (id) => {
    if (!confirm('למחוק פרסום זה?')) return;
    await supabase.from('announcements').delete().eq('id', id);
    if (form.id === id) reset();
    load();
  };

  const toggle = async (it) => {
    await supabase.from('announcements').update({ active: !it.active }).eq('id', it.id);
    load();
  };

  return (
    <>
      <div className="card">
        <div className="section-title">{form.id ? 'עריכת פרסום' : 'פרסום חדש'}</div>
        <div className="field">
          <label>כותרת</label>
          <input value={form.title || ''} onChange={(e) => set('title', e.target.value)} placeholder="לדוגמה: שיעור הרב בערב" />
        </div>
        <div className="field">
          <label>תוכן ההודעה</label>
          <textarea value={form.body || ''} onChange={(e) => set('body', e.target.value)} placeholder="פרטי ההודעה…" />
        </div>
        <div className="field">
          <label>תמונה (לא חובה)</label>
          <input type="file" accept="image/*" onChange={(e) => uploadImage(e.target.files?.[0])} />
          {uploading && <p className="muted">מעלה…</p>}
          {form.image_url && (
            <div style={{ marginTop: '0.5rem' }}>
              <img src={form.image_url} alt="" style={{ maxWidth: '100%', borderRadius: 10 }} />
              <button className="btn btn--ghost" style={{ marginTop: '0.4rem' }} onClick={() => set('image_url', '')}>
                הסר תמונה
              </button>
            </div>
          )}
        </div>
        <div className="grid-2">
          <div className="field">
            <label>סדר תצוגה</label>
            <input type="number" value={form.sort_order} onChange={(e) => set('sort_order', e.target.value)} />
          </div>
          <div className="field" style={{ display: 'flex', alignItems: 'flex-end' }}>
            <label className="switch">
              <input type="checkbox" checked={!!form.active} onChange={(e) => set('active', e.target.checked)} />
              מוצג על הלוח
            </label>
          </div>
        </div>
        <div className="btn-row">
          <button className="btn" onClick={save}>
            {form.id ? 'עדכן' : 'פרסם'}
          </button>
          {form.id && (
            <button className="btn btn--ghost" onClick={reset}>
              ביטול
            </button>
          )}
        </div>
      </div>

      <div className="section-title">הפרסומים הקיימים</div>
      {items.length === 0 && <p className="muted">עדיין אין פרסומים. הוסף למעלה.</p>}
      {items.map((it) => (
        <div className={'list-item' + (it.active ? '' : ' is-off')} key={it.id}>
          {it.image_url && <img className="list-item__thumb" src={it.image_url} alt="" />}
          <div className="list-item__main">
            <div className="list-item__label">{it.title || '(ללא כותרת)'}</div>
            {it.body && <div className="list-item__sub" style={{ direction: 'rtl' }}>{it.body.slice(0, 40)}</div>}
          </div>
          <label className="switch">
            <input type="checkbox" checked={it.active} onChange={() => toggle(it)} />
          </label>
          <button className="btn btn--ghost" onClick={() => edit(it)}>
            ערוך
          </button>
          <button className="btn btn--danger" onClick={() => remove(it.id)}>
            מחק
          </button>
        </div>
      ))}
    </>
  );
}

/* ---------- Root ---------- */
export default function Admin() {
  const [tab, setTab] = useState('settings');
  const [toast, toastNode] = useToast();
  const needPin = Boolean(ADMIN_PIN);
  const [unlocked, setUnlocked] = useState(!needPin || sessionStorage.getItem('admin_ok') === '1');

  if (needPin && !unlocked) return <PinGate onUnlock={() => setUnlocked(true)} />;

  return (
    <div className="admin">
      <div className="admin__top">
        <div className="admin__title">ניהול הלוח</div>
        <a className="btn btn--ghost" href="/" target="_blank" rel="noreferrer">
          צפה בלוח
        </a>
      </div>

      {!isSupabaseConfigured && (
        <div className="banner">
          Supabase עדיין לא מחובר. השינויים לא יישמרו עד שתגדיר את משתני הסביבה
          <code> VITE_SUPABASE_URL </code> ו־<code> VITE_SUPABASE_ANON_KEY </code> ב־Vercel. ראה README.
        </div>
      )}

      <div className="tabs">
        <button className={'tab' + (tab === 'settings' ? ' tab--active' : '')} onClick={() => setTab('settings')}>
          הגדרות
        </button>
        <button className={'tab' + (tab === 'prayers' ? ' tab--active' : '')} onClick={() => setTab('prayers')}>
          זמני תפילה
        </button>
        <button className={'tab' + (tab === 'announce' ? ' tab--active' : '')} onClick={() => setTab('announce')}>
          פרסומים
        </button>
      </div>

      {tab === 'settings' && <SettingsTab toast={toast} />}
      {tab === 'prayers' && <PrayersTab toast={toast} />}
      {tab === 'announce' && <AnnouncementsTab toast={toast} />}

      {toastNode}
    </div>
  );
}
